export const PRODUCTS_PER_PAGE = 30;
export const TYPES_PER_PAGE = 15;
export const CATEGORIES_PER_PAGE = 1000;
export const SHOPS_PER_PAGE = 30;
export const AUTHORS_PER_PAGE = 30;
export const MANUFACTURERS_PER_PAGE = 30;
