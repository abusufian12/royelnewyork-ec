export const termsAndServices = {
  title: 'terms-main-title',
  date: '01/01/2020',
  content: [
    {
      id: '1',
      title: 'terms-one-title',
      description: 'terms-one-description',
    },
    {
      id: '2',
      title: 'terms-two-title',
      description: 'terms-two-description',
    },
    {
      id: '3',
      title: 'terms-three-title',
      description: 'terms-three-description',
    },
    {
      id: '4',
      title: 'terms-four-title',
      description: 'terms-four-description',
    },
    {
      id: '5',
      title: 'terms-five-title',
      description: 'terms-five-description',
    },
    {
      id: '6',
      title: 'terms-six-title',
      description: 'terms-six-description',
    },
  ],
};
