import 'rc-slider/assets/index.css';
export { default } from 'rc-slider';
