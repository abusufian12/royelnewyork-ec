export { default as Image } from 'next/image';
