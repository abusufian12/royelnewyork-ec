import 'rc-collapse/assets/index.css';
export { default as Collapse } from 'rc-collapse';
